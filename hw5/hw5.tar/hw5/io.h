#ifndef IO_H
#define IO_H

  short ax;
  short bx;
  short cx;
  short dx;

  void read(char*);
  void print(char*);
  void move(char*, char*);

#endif
