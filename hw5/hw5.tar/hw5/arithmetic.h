#ifndef ARITHMETIC_H
#define ARITHMETIC_H

  void add(char*, char*);
  void sub(char*, char*);
  void mul(char*, char*);
  void divide(char*, char*);

#endif
