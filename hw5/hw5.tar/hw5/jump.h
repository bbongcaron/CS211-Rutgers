#ifndef JUMP_H
#define JUMP_H

int je(char*, char*);
int jne(char*, char*);
int jg(char*, char*);
int jge(char*, char*);
int jl(char*, char*);
int jle(char*, char*);

#endif
